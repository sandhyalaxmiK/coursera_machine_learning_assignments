function [J, grad] = costFunction(theta, X, y)
%COSTFUNCTION Compute cost and gradient for logistic regression
%   J = COSTFUNCTION(theta, X, y) computes the cost of using theta as the
%   parameter for logistic regression and the gradient of the cost
%   w.r.t. to the parameters.

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta.
%               You should set J to the cost.
%               Compute the partial derivatives and set grad to the partial
%               derivatives of the cost w.r.t. each parameter in theta
%
% Note: grad should have the same dimensions as theta
theta_prev=theta;
z=X*theta_prev;
sigm_X=(1+exp(-z)).^(-1);
%sigm_X=sigmoid(X);
J=(-y'*log(sigm_X)-(1-y)'*log(1-sigm_X))/m
%reg_term=(lambda*sum(theta(2:size(theta,1)).^2))/(2*m)
%J=(cost_term+reg_term)
n=size(X,2);
grad(1)=(X(:,1)'*(sigm_X-y))/m;
for k=2:n
	% error=(sigm_X-y)'*X(:,k);
	error=X(:,k)'*(sigm_X-y);
	grad(k)=(sum(error))/m;
end



%sigm_X=sigmoid(X);
cost_term=-y'*log(sigm_X)-(1-y)'*log(1-sigm_X);
%size(cost_term)
J=sum(cost_term)/m;
n=size(X,2);
for k=1:n
	%error=(sigm_X-y)'*X(:,k);
	error=X(:,k)'*(sigm_X-y);
	grad(k)=sum(error)/m;
end
% =============================================================
end
