input_layer_size  = 400;  % 20x20 Input Images of Digits
hidden_layer_size = 25;   % 25 hidden units
num_labels = 10;          % 10 labels, from 1 to 10   
                          % (note that we have mapped "0" to label 10)

load('ex4data1.mat');
m = size(X, 1);
load('ex4weights.mat');
% Unroll parameters 
nn_params = [Theta1(:) ; Theta2(:)];
lambda = 0;
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));
                 
J = 0;

Y=zeros(m,num_labels);
Y(sub2ind(size(Y),[1:m],y'))=1;
a1=X;
a1=[ones(m,1) a1];
z2=a1*Theta1';
a2=sigmoid(z2);
a2=[ones(size(a2,1),1) a2];
z3=a2*Theta2';
a3=sigmoid(z3);
size(a3);
size(Y);


cost_term=sum(sum((-Y.*log(a3)-(1-Y).*log(1-a3)),2))/m
%size(cost_term)
reg_term=(sum(sum(Theta1(:,2:end).*2,2))+sum(sum(Theta2(:,2:end).*2,2)))*lambda/(2*m)
J=cost_term+reg_term


