load ('ex5data1.mat');

m = size(X, 1);
theta = [1 ; 1];
X=[ones(m,1) X]
z=X*theta
%h_of_x=(1+exp(-z)).^(-1)
h_of_x=z
error=sum((h_of_x-y).^2)/(2*m)
lambda=1
reg_term=sum(theta(2:end).^2)*lambda/(2*m)
J=error+reg_term
n=size(X,2);
grad(1)=(X(:,1)'*(h_of_x-y))/m;
for k=2:n
	% error=(sigm_X-y)'*X(:,k);
	error=X(:,k)'*(h_of_x-y);
	grad(k)=(sum(error))/m+lambda*theta(k)/m;
end

error_train = zeros(m, 1);
error_val   = zeros(m, 1);
m_val=size(Xval,1)
Xval=[ones(m_val,1) Xval]
X_train=X(1,:)
y_train=y(1)
theta(1)=0;
theta(2)=y_train/X_train(2);
z_train=X_train*theta;
m_train=size(X_train,1)
error_train(1)=sum((z_train-y_train).^2)/(2*m_train);
z_val=Xval*theta;
error_val(1)=sum(z_val-yval).^2/(2*m_val);

for i=2:m
	X_train=X(1:i,:)
	y_train=y(1:i)
	theta=trainLinearReg(X_train,y_train,0)
	z_train=X_train*theta;
	m_train=size(X_train,1)
	error_train(i)=sum((z_train-y_train).^2)/(2*m_train);
	z_val=Xval*theta;
	error_val(i)=sum(z_val-yval).^2/(2*m_val);
end


plot(1:m, error_train, 1:m, error_val);
title('Learning curve for linear regression')
legend('Train', 'Cross Validation')
xlabel('Number of training examples')
ylabel('Error')
axis([0 13 0 150])
for i = 1:m
    fprintf('  \t%d\t\t%f\t%f\n', i, error_train(i), error_val(i));
end


