load ('ex8_movies.mat');
num_users = 4; num_movies = 5; num_features = 3;
X = X(1:num_movies, 1:num_features);
Theta = Theta(1:num_users, 1:num_features);
Y = Y(1:num_movies, 1:num_users);
R = R(1:num_movies, 1:num_users);
params=[X(:) ; Theta(:)];
lambda=0;
     
X = reshape(params(1:num_movies*num_features), num_movies, num_features);
Theta = reshape(params(num_movies*num_features+1:end), ...
                num_users, num_features)
J = 0;
X_grad = zeros(size(X));
Theta_grad = zeros(size(Theta));
temp=((X*Theta')-Y).*R;
J=(sum(sum(temp.^2)))/2;
%size(X*Theta')
X_grad=temp*Theta
Theta_grad=temp'*X;
for i=1:size(X_grad,1)
	X_grad(i,:)=X_grad+lambda*X(i)
end
for j=1:size(Theta_grad,1)
	Theta_grad(j,:)=Theta_grad+lambda*Theta(j)
end
