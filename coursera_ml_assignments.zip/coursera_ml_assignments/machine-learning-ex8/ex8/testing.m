load('ex8data1.mat');
[mu sigma2] = estimateGaussian(X);
p = multivariateGaussian(X, mu, sigma2);
pval = multivariateGaussian(Xval, mu, sigma2);
%[epsilon F1] = selectThreshold(yval, pval);
bestEpsilon = 0;
bestF1 = 0;
F1 = 0;
stepsize = (max(pval) - min(pval)) / 1000;

for epsilon = min(pval):stepsize:max(pval)
   	predictions=(pval<epsilon);
	True_positives=0;
	False_positives=0;
	True_negatives=0;
	False_negatives=0;
	for i=1:size(pval,1)
		if (predictions(i)==1) and (yval(i)==1)
			True_positives+=1;
		elseif (predictions(i)==1) and (yval(i)==0)
			False_positives+=1; 
		elseif (predictions(i)==0) and (yval(i)==1)
			True_negatives+=1;
		else
			False_negatives+=1;
		end
	end
	
	Precision=True_positives/(True_positives+False_positives);
	Recall=True_positives/(True_positives+True_negatives);
	F1=(2*Precision*Recall)/(Precision+Recall);
	if F1<bestF1
		bestF1=F1;
	end
end

	


