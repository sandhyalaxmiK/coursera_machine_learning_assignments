input_layer_size  = 400;  % 20x20 Input Images of Digits
hidden_layer_size = 25;   % 25 hidden units
num_labels = 10;          % 10 labels, from 1 to 10   
load('ex4data1.mat');
m = size(X, 1);
% Load the weights into variables Theta1 and Theta2
load('ex4weights.mat');

% Unroll parameters 
nn_params = [Theta1(:) ; Theta2(:)];

% Weight regularization parameter (we set this to 0 here).
lambda = 0;
z=[-1 -0.5 0 0.5 1];
g=sigmoid(z).*(1-sigmoid(z));
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

I=eye(num_labels);
Y=zeros(m,10);
for k=1:m
     Y(k,:)=I(y(k,1),:);
end;
%predicting y values
X=[ones(m,1) X];
a1=X;
z2=X*Theta1';
a2=sigmoid(z2);
z3=[ones(m,1) a2];
a3=sigmoid(z3*Theta2');
h=a3;
cost_term=-Y.*log(h)-(1-Y).*log(1-h);
%before adding regularization term
J=sum(sum(cost_term))/m;
%regularization_term
reg_term=(sum(sum(Theta1(:,2:end).^2))+sum(sum(Theta2(:,2:end).^2)))*lambda/(2*m);
J=J+reg_term;
small_delta3=a3-Y;
a2=[ones(m,1) a2];
small_delta2=small_delta3*Theta2.*(a2.*(1-a2))';
big_delta2=a2'*small_delta3;
big_delta1=small_delta2*a1;
Theta1_grad(1)=big_delta1(1)/m;
size(X)
size(z2)
size(z3)
size(a1)
size(a2)
size(a3)
size(small_delta3)
size(small_delta2)
size(big_delta2)
size(big_delta1)

size(Theta1_grad)
size(big_delta1)
size(Theta1)
size(Theta2)


for k=2:size(Theta1,2)
	Theta1_grad(k,:)=big_delta1(k,:)/m+(lambda/m)*Theta1(k,:);
end;
Theta2_grad(1)=big_delta2(1)/m;
for k=2:m
	Theta2_grad(:,k)=big_delta1(:,k)/m+(lambda/m)*Theta2(:,k);
end;
grad = [Theta1_grad(:) ; Theta2_grad(:)];

