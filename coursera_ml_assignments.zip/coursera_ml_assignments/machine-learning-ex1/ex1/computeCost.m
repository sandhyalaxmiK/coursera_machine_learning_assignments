function J = computeCost(X, y, theta)
%COMPUTECOST Compute cost for linear regression
%   J = COMPUTECOST(X, y, theta) computes the cost of using theta as the
%   parameter for linear regression to fit the data points in X and y

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta
%               You should set J to the cost.

%Data=load('ex1data1.txt');
%X=Data(:,1);
%y=Data(:,2);
%m=length(y);
%X=[ones(m,1),Data(:,1)];   %adding 1 column vector of size m at begining of matrix X for the sake of theta0
%theta=zeros(2,1)  % need to fit two values theta0,theta1 in h(x)=theta0+theta1*x
predictions=X*theta;
sqrErrors=(predictions-y).^2;
J=1/(2*m)*sum(sqrErrors);
% =========================================================================

end
