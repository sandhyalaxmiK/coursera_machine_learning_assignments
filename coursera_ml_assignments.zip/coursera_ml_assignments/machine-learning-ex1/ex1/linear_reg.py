import cv2
import os
data=open('ex1data1.txt','rb')
