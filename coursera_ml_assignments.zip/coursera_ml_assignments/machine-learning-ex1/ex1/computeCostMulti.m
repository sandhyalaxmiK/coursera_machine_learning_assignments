function J = computeCostMulti(X, y, theta)
%COMPUTECOSTMULTI Compute cost for linear regression with multiple variables
%   J = COMPUTECOSTMULTI(X, y, theta) computes the cost of using theta as the
%   parameter for linear regression to fit the data points in X and y
Data=load('ex1data2.txt');
X=Data(:,1:size(Data,2)-1);
y=Data(:,size(Data,2));
m=length(y);
X=[ones(m,1),X];   %adding 1 column vector of size m at begining of matrix X for the sake of theta0
n=size(X,2);
theta=zeros(n,1);
% Initialize some useful values
%m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta
%               You should set J to the cost.

predictions=X*theta;
sqrErrors=(predictions-y).^2;
J=1/(2*m)*sum(sqrErrors);



% =========================================================================

end
